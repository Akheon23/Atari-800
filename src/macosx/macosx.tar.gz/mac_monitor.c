/*
 * mac_monitor.c - Implements a builtin system monitor for debugging
 *
 * Copyright (C) 1995-1998 David Firth
 * Copyright (C) 1998-2003 Atari800 development team (see DOC/CREDITS)
 *
 * This file is part of the Atari800 emulator project which emulates
 * the Atari 400, 800, 800XL, 130XE, and 5200 8-bit computers.
 *
 * Atari800 is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Atari800 is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Atari800; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#include "atari.h"
#include "config.h"
#include "cpu.h"
#include "memory.h"
#include "antic.h"
#include "pia.h"
#include "gtia.h"
#include "pokey.h"
#include "prompts.h"
#include "rt-config.h"

void ControlManagerMonitorPrint(char *string);

#ifdef PROFILE
extern int instruction_count[256];
#endif
extern int cycles[256];

extern UWORD dlist;

#ifdef TRACE
int tron = FALSE;
#endif

unsigned int disassemble(UWORD addr1, UWORD addr2);
UWORD show_instruction(UWORD inad, int wid);

static UWORD addr = 0;

#ifdef MONITOR_ASSEMBLER
UWORD assembler(char *input);
int assemblerMode = FALSE;
static UWORD assemblerAddr;
#endif
#ifdef MONITOR_HINTS
  typedef struct {
    char name[9];  /* max. 8 characters */
    UWORD addr;
  } symtable_rec;
  /*SYMBOL NAMES TAKEN FROM atari.equ - part of disassembler by Erich BACHER 
    and from GTIA.H, POKEY.H, PIA.H & ANTIC.H                                */
  /*Note: all symbols must be sorted by address (binary search is used).
    Maximal length of symbol name is 8 characters (can be changed above).
    If the adress has different names when reading/writting to it (GTIA ports),
    put the read name first. */
    
  symtable_rec symtable[] = { 
    {"NGFLAG",  0x0001}, {"CASINI",  0x0002}, {"CASINI+1",0x0003}, {"RAMLO",   0x0004},
    {"RAMLO+1", 0x0005}, {"TRAMSZ",  0x0006}, {"CMCMD",   0x0007}, {"WARMST",  0x0008},
    {"BOOT",    0x0009}, {"DOSVEC",  0x000a}, {"DOSVEC+1",0x000b}, {"DOSINI",  0x000c},
    {"DOSINI+1",0x000d}, {"APPMHI",  0x000e}, {"APPMHI+1",0x000f}, {"POKMSK",  0x0010},
    {"BRKKEY",  0x0011}, {"RTCLOK",  0x0012}, {"RTCLOK+1",0x0013}, {"RTCLOK+2",0x0014},
    {"BUFADR",  0x0015}, {"BUFADR+1",0x0016}, {"ICCOMT",  0x0017}, {"DSKFMS",  0x0018},
    {"DSKFMS+1",0x0019}, {"DSKUTL",  0x001a}, {"DSKUTL+1",0x001b}, {"ABUFPT",  0x001c},
    {"ABUFPT+1",0x001d}, {"ABUFPT+2",0x001e}, {"ABUFPT+3",0x001f},
    {"ICHIDZ",  0x0020}, {"ICDNOZ",  0x0021}, {"ICCOMZ",  0x0022}, {"ICSTAZ",  0x0023},
    {"ICBALZ",  0x0024}, {"ICBAHZ",  0x0025}, {"ICPTLZ",  0x0026}, {"ICPTHZ",  0x0027},
    {"ICBLLZ",  0x0028}, {"ICBLHZ",  0x0029}, {"ICAX1Z",  0x002A}, {"ICAX2Z",  0x002B},
    {"ICAX3Z",  0x002C}, {"ICAX4Z",  0x002D}, {"ICAX5Z",  0x002E}, {"ICAX6Z",  0x002F},
    {"STATUS",  0x0030}, {"CHKSUM",  0x0031}, {"BUFRLO",  0x0032}, {"BUFRHI",  0x0033},
    {"BFENLO",  0x0034}, {"BFENHI",  0x0035}, {"LTEMP" ,  0x0036}, {"LTEMP+1", 0x0037},
    {"BUFRFL",  0x0038}, {"RECVDN",  0x0039}, {"XMTDON",  0x003A}, {"CHKSNT",  0x003B},
    {"NOCKSM",  0x003C}, {"BPTR"  ,  0x003D}, {"FTYPE" ,  0x003E}, {"FEOF"  ,  0x003F},
    {"FREQ"  ,  0x0040}, {"SOUNDR",  0x0041}, {"CRITIC",  0x0042}, {"FMSZPG",  0x0043},
    {"FMSZPG+1",0x0044}, {"FMSZPG+2",0x0045}, {"FMSZPG+3",0x0046}, {"FMSZPG+4",0x0047},
    {"FMSZPG+5",0x0048}, {"FMSZPG+6",0x0049}, {"ZCHAIN",  0x004A}, {"ZCHAIN+1",0x004B},
    {"DSTAT" ,  0x004C}, {"ATRACT",  0x004D}, {"DRKMSK",  0x004E}, {"COLRSH",  0x004F},
    {"TEMP"  ,  0x0050}, {"HOLD1" ,  0x0051}, {"LMARGN",  0x0052}, {"RMARGN",  0x0053},
    {"ROWCRS",  0x0054}, {"COLCRS",  0x0055}, {"COLCRS+1",0x0056}, {"DINDEX",  0x0057},
    {"SAVMSC",  0x0058}, {"SAVMSC+1",0x0059}, {"OLDROW",  0x005A}, {"OLDCOL",  0x005B},
    {"OLDCOL+1",0x005C}, {"OLDCHR",  0x005D}, {"OLDADR",  0x005E}, {"OLDADR+1",0x005F},
    {"FKDEF" ,  0x0060}, {"FKDEF+1", 0x0061}, {"PALNTS",  0x0062}, {"LOGCOL",  0x0063},
    {"ADRESS",  0x0064}, {"ADRESS+1",0x0065}, {"MLTTMP",  0x0066}, {"MLTTMP+1",0x0067},
    {"SAVADR",  0x0068}, {"SAVADR+1",0x0069}, {"RAMTOP",  0x006A}, {"BUFCNT",  0x006B},
    {"BUFSTR",  0x006C}, {"BUFSTR+1",0x006D}, {"BITMSK",  0x006E}, {"SHFAMT",  0x006F},
    {"ROWAC" ,  0x0070}, {"ROWAC+1", 0x0071}, {"COLAC" ,  0x0072}, {"COLAC+1", 0x0073},
    {"ENDPT" ,  0x0074}, {"ENDPT+1", 0x0075}, {"DELTAR",  0x0076}, {"DELTAC",  0x0077},
    {"DELTAC+1",0x0078}, {"KEYDEF",  0x0079}, {"KEYDEF+1",0x007A}, {"SWPFLG",  0x007B},
    {"HOLDCH",  0x007C}, {"INSDAT",  0x007D}, {"COUNTR",  0x007E}, {"COUNTR+1",0x007F},
    {"LOMEM" ,  0x0080}, {"LOMEM+1", 0x0081}, {"VNTP"  ,  0x0082}, {"VNTP+1",  0x0083},
    {"VNTD"  ,  0x0084}, {"VNTD+1",  0x0085}, {"VVTP"  ,  0x0086}, {"VVTP+1",  0x0087},
    {"STMTAB",  0x0088}, {"STMTAB+1",0x0089}, {"STMCUR",  0x008A}, {"STMCUR+1",0x008B},
    {"STARP" ,  0x008C}, {"STARP+1", 0x008D}, {"RUNSTK",  0x008E}, {"RUNSTK+1",0x008F},
    {"TOPSTK",  0x0090}, {"TOPSTK+1",0x0091}, {"MEOLFLG", 0x0092}, {"POKADR",  0x0095},
    {"POKADR+1",0x0096}, {"DATAD" ,  0x00B6}, {"DATALN",  0x00B7}, {"DATALN+1",0x00B8},
    {"STOPLN",  0x00BA}, {"STOPLN+1",0x00BB}, {"SAVCUR",  0x00BE}, {"IOCMD" ,  0x00C0},
    {"IODVC" ,  0x00C1}, {"PROMPT",  0x00C2}, {"ERRSAVE", 0x00C3}, {"COLOUR",  0x00C8},
    {"PTABW" ,  0x00C9}, {"LOADFLG", 0x00CA}, {"FR0"   ,  0x00D4}, {"FR0+1" ,  0x00D5},
    {"FR0+2" ,  0x00D6}, {"FR0+3" ,  0x00D7}, {"FR0+4" ,  0x00D8}, {"FR0+5" ,  0x00D9},
    {"FRE"   ,  0x00DA}, {"FRE+1" ,  0x00DB}, {"FRE+2" ,  0x00DC}, {"FRE+3" ,  0x00DD},
    {"FRE+4" ,  0x00DE}, {"FRE+5" ,  0x00DF}, {"FR1"   ,  0x00E0}, {"FR1+1" ,  0x00E1},
    {"FR1+2" ,  0x00E2}, {"FR1+3" ,  0x00E3}, {"FR1+4" ,  0x00E4}, {"FR1+5" ,  0x00E5},
    {"FR2"   ,  0x00E6}, {"FR2+1" ,  0x00E7}, {"FR2+2" ,  0x00E8}, {"FR2+3" ,  0x00E9},
    {"FR2+4" ,  0x00EA}, {"FR2+5" ,  0x00EB}, {"FRX"   ,  0x00EC}, {"EEXP"  ,  0x00ED},
    {"NSIGN" ,  0x00EE}, {"ESIGN" ,  0x00EF}, {"FCHRFLG", 0x00F0}, {"DIGRT" ,  0x00F1},
    {"CIX"   ,  0x00F2}, {"INBUFF",  0x00F3}, {"INBUFF+1",0x00F4}, {"ZTEMP1",  0x00F5},
    {"ZTEMP1+1",0x00F6}, {"ZTEMP4",  0x00F7}, {"ZTEMP4+1",0x00F8}, {"ZTEMP3",  0x00F9},
    {"ZTEMP3+1",0x00FA}, {"RADFLG",  0x00FB}, {"FLPTR" ,  0x00FC}, {"FLPTR+1", 0x00FD},
    {"FPTR2" ,  0x00FE}, {"FPTR2+1", 0x00FF},

    {"VDSLST",  0x0200}, {"VDSLST+1",0x0201}, {"VPRCED",  0x0202}, {"VPRCED+1",0x0203},
    {"VINTER",  0x0204}, {"VINTER+1",0x0205}, {"VBREAK",  0x0206}, {"VBREAK+1",0x0207},
    {"VKEYBD",  0x0208}, {"VKEYBD+1",0x0209}, {"VSERIN",  0x020A}, {"VSERIN+1",0x020B},
    {"VSEROR",  0x020C}, {"VSEROR+1",0x020D}, {"VSEROC",  0x020E}, {"VSEROC+1",0x020F},
    {"VTIMR1",  0x0210}, {"VTIMR1+1",0x0211}, {"VTIMR2",  0x0212}, {"VTIMR2+1",0x0213},
    {"VTIMR4",  0x0214}, {"VTIMR4+1",0x0215}, {"VIMIRQ",  0x0216}, {"VIMIRQ+1",0x0217},
    {"CDTMV1",  0x0218}, {"CDTMV1+1",0x0219}, {"CDTMV2",  0x021A}, {"CDTMV2+1",0x021B},
    {"CDTMV3",  0x021C}, {"CDTMV3+1",0x021D}, {"CDTMV4",  0x021E}, {"CDTMV4+1",0x021F},
    {"CDTMV5",  0x0220}, {"CDTMV5+1",0x0221}, {"VVBLKI",  0x0222}, {"VVBLKI+1",0x0223},
    {"VVBLKD",  0x0224}, {"VVBLKD+1",0x0225}, {"CDTMA1",  0x0226}, {"CDTMA1+1",0x0227},
    {"CDTMA2",  0x0228}, {"CDTMA2+1",0x0229}, {"CDTMF3",  0x022A}, {"SRTIMR",  0x022B},
    {"CDTMF4",  0x022C}, {"INTEMP",  0x022D}, {"CDTMF5",  0x022E}, {"SDMCTL",  0x022F},
    {"SDLSTL",  0x0230}, {"SDLSTH",  0x0231}, {"SSKCTL",  0x0232}, {"SPARE" ,  0x0233},
    {"LPENH" ,  0x0234}, {"LPENV" ,  0x0235}, {"BRKKY" ,  0x0236}, {"BRKKY+1", 0x0237},
    {"VPIRQ" ,  0x0238}, {"VPIRQ+1", 0x0239}, {"CDEVIC",  0x023A}, {"CCOMND",  0x023B},
    {"CAUX1" ,  0x023C}, {"CAUX2" ,  0x023D}, {"TMPSIO",  0x023E}, {"ERRFLG",  0x023F},
    {"DFLAGS",  0x0240}, {"DBSECT",  0x0241}, {"BOOTAD",  0x0242}, {"BOOTAD+1",0x0243},
    {"COLDST",  0x0244}, {"RECLEN",  0x0245}, {"DSKTIM",  0x0246}, {"PDVMSK",  0x0247},
    {"SHPDVS",  0x0248}, {"PDMSK" ,  0x0249}, {"RELADR",  0x024A}, {"RELADR+1",0x024B},
    {"PPTMPA",  0x024C}, {"PPTMPX",  0x024D}, {"CHSALT",  0x026B}, {"VSFLAG",  0x026C},
    {"KEYDIS",  0x026D}, {"FINE"  ,  0x026E}, {"GPRIOR",  0x026F}, {"PADDL0",  0x0270},
    {"PADDL1",  0x0271}, {"PADDL2",  0x0272}, {"PADDL3",  0x0273}, {"PADDL4",  0x0274},
    {"PADDL5",  0x0275}, {"PADDL6",  0x0276}, {"PADDL7",  0x0277}, {"STICK0",  0x0278},
    {"STICK1",  0x0279}, {"STICK2",  0x027A}, {"STICK3",  0x027B}, {"PTRIG0",  0x027C},
    {"PTRIG1",  0x027D}, {"PTRIG2",  0x027E}, {"PTRIG3",  0x027F}, {"PTRIG4",  0x0280},
    {"PTRIG5",  0x0281}, {"PTRIG6",  0x0282}, {"PTRIG7",  0x0283}, {"STRIG0",  0x0284},
    {"STRIG1",  0x0285}, {"STRIG2",  0x0286}, {"STRIG3",  0x0287}, {"HIBYTE",  0x0288},
    {"WMODE" ,  0x0289}, {"BLIM"  ,  0x028A}, {"IMASK" ,  0x028B}, {"JVECK" ,  0x028C},
    {"NEWADR",  0x028E}, {"TXTROW",  0x0290}, {"TXTCOL",  0x0291}, {"TXTCOL+1",0x0292},
    {"TINDEX",  0x0293}, {"TXTMSC",  0x0294}, {"TXTMSC+1",0x0295}, {"TXTOLD",  0x0296},
    {"TXTOLD+1",0x0297}, {"TXTOLD+2",0x0298}, {"TXTOLD+3",0x0299}, {"TXTOLD+4",0x029A},
    {"TXTOLD+5",0x029B}, {"CRETRY",  0x029C}, {"HOLD3" ,  0x029D}, {"SUBTMP",  0x029E},
    {"HOLD2" ,  0x029F}, {"DMASK" ,  0x02A0}, {"TMPLBT",  0x02A1}, {"ESCFLG",  0x02A2},
    {"TABMAP",  0x02A3}, {"TABMAP+1",0x02A4}, {"TABMAP+2",0x02A5}, {"TABMAP+3",0x02A6},
    {"TABMAP+4",0x02A7}, {"TABMAP+5",0x02A8}, {"TABMAP+6",0x02A9}, {"TABMAP+7",0x02AA},
    {"TABMAP+8",0x02AB}, {"TABMAP+9",0x02AC}, {"TABMAP+A",0x02AD}, {"TABMAP+B",0x02AE},
    {"TABMAP+C",0x02AF}, {"TABMAP+D",0x02B0}, {"TABMAP+E",0x02B1}, {"LOGMAP",  0x02B2},
    {"LOGMAP+1",0x02B3}, {"LOGMAP+2",0x02B4}, {"LOGMAP+3",0x02B5}, {"INVFLG",  0x02B6},
    {"FILFLG",  0x02B7}, {"TMPROW",  0x02B8}, {"TMPCOL",  0x02B9}, {"TMPCOL+1",0x02BA},
    {"SCRFLG",  0x02BB}, {"HOLD4" ,  0x02BC}, {"DRETRY",  0x02BD}, {"SHFLOC",  0x02BE},
    {"BOTSCR",  0x02BF}, {"PCOLR0",  0x02C0}, {"PCOLR1",  0x02C1}, {"PCOLR2",  0x02C2},
    {"PCOLR3",  0x02C3}, {"COLOR0",  0x02C4}, {"COLOR1",  0x02C5}, {"COLOR2",  0x02C6},
    {"COLOR3",  0x02C7}, {"COLOR4",  0x02C8}, {"RUNADR",  0x02C9}, {"RUNADR+1",0x02CA},
    {"HIUSED",  0x02CB}, {"HIUSED+1",0x02CC}, {"ZHIUSE",  0x02CD}, {"ZHIUSE+1",0x02CE},
    {"GBYTEA",  0x02CF}, {"GBYTEA+1",0x02D0}, {"LOADAD",  0x02D1}, {"LOADAD+1",0x02D2},
    {"ZLOADA",  0x02D3}, {"ZLOADA+1",0x02D4}, {"DSCTLN",  0x02D5}, {"DSCTLN+1",0x02D6},
    {"ACMISR",  0x02D7}, {"ACMISR+1",0x02D8}, {"KRPDER",  0x02D9}, {"KEYREP",  0x02DA},
    {"NOCLIK",  0x02DB}, {"HELPFG",  0x02DC}, {"DMASAV",  0x02DD}, {"PBPNT" ,  0x02DE},
    {"PBUFSZ",  0x02DF}, {"RUNAD" ,  0x02E0}, {"RUNAD+1", 0x02E1}, {"INITAD",  0x02E2},
    {"INITAD+1",0x02E3}, {"RAMSIZ",  0x02E4}, {"MEMTOP",  0x02E5}, {"MEMTOP+1",0x02E6},
    {"MEMLO" ,  0x02E7}, {"MEMLO+1", 0x02E8}, {"HNDLOD",  0x02E9}, {"DVSTAT",  0x02EA},
    {"DVSTAT+1",0x02EB}, {"DVSTAT+2",0x02EC}, {"DVSTAT+3",0x02ED}, {"CBAUDL",  0x02EE},
    {"CBAUDH",  0x02EF}, {"CRSINH",  0x02F0}, {"KEYDEL",  0x02F1}, {"CH1"   ,  0x02F2},
    {"CHACT" ,  0x02F3}, {"CHBAS" ,  0x02F4}, {"NEWROW",  0x02F5}, {"NEWCOL",  0x02F6},
    {"NEWCOL+1",0x02F7}, {"ROWINC",  0x02F8}, {"COLINC",  0x02F9}, {"CHAR"  ,  0x02FA},
    {"ATACHR",  0x02FB}, {"CH"    ,  0x02FC}, {"FILDAT",  0x02FD}, {"DSPFLG",  0x02FE},
    {"SSFLAG",  0x02FF},


    {"DDEVIC",  0x0300}, {"DUNIT"   ,0x0301}, {"DCOMND"  ,0x0302}, {"DSTATS"  ,0x0303},
    {"DBUFLO"  ,0x0304}, {"DBUFHI"  ,0x0305}, {"DTIMLO"  ,0x0306}, {"DUNUSE"  ,0x0307},
    {"DBYTLO"  ,0x0308}, {"DBYTHI"  ,0x0309}, {"DAUX1"   ,0x030A}, {"DAUX2"   ,0x030B},
    {"TIMER1"  ,0x030C}, {"TIMER1+1",0x030D}, {"ADDCOR"  ,0x030E}, {"CASFLG"  ,0x030F},
    {"TIMER2"  ,0x0310}, {"TIMER2+1",0x0311}, {"TEMP1"   ,0x0312}, {"TEMP1+1", 0x0313},
    {"TEMP2"   ,0x0314}, {"TEMP3"   ,0x0315}, {"SAVIO"   ,0x0316}, {"TIMFLG",  0x0317},
    {"STACKP",  0x0318}, {"TSTAT"   ,0x0319},
    {"HATABS",  0x031a},  /*HATABS 1-34*/
    {"PUTBT1",  0x033d}, {"PUTBT2",  0x033e}, {"PUTBT3",  0x033f},
    {"B0-ICHID",0x0340}, {"B0-ICDNO",0x0341}, {"B0-ICCOM",0x0342}, {"B0-ICSTA",0x0343},
    {"B0-ICBAL",0x0344}, {"B0-ICBAH",0x0345}, {"B0-ICPTL",0x0346}, {"B0-ICPTH",0x0347},
    {"B0-ICBLL",0x0348}, {"B0-ICBLH",0x0349}, {"B0-ICAX1",0x034a}, {"B0-ICAX2",0x034b},
    {"B0-ICAX3",0x034c}, {"B0-ICAX4",0x034d}, {"B0-ICAX5",0x034e}, {"B0-ICAX6",0x034f},
    {"B1-ICHID",0x0350}, {"B1-ICDNO",0x0351}, {"B1-ICCOM",0x0352}, {"B1-ICSTA",0x0353},
    {"B1-ICBAL",0x0354}, {"B1-ICBAH",0x0355}, {"B1-ICPTL",0x0356}, {"B1-ICPTH",0x0357},
    {"B1-ICBLL",0x0358}, {"B1-ICBLH",0x0359}, {"B1-ICAX1",0x035a}, {"B1-ICAX2",0x035b},
    {"B1-ICAX3",0x035c}, {"B1-ICAX4",0x035d}, {"B1-ICAX5",0x035e}, {"B1-ICAX6",0x035f},
    {"B2-ICHID",0x0360}, {"B2-ICDNO",0x0361}, {"B2-ICCOM",0x0362}, {"B2-ICSTA",0x0363},
    {"B2-ICBAL",0x0364}, {"B2-ICBAH",0x0365}, {"B2-ICPTL",0x0366}, {"B2-ICPTH",0x0367},
    {"B2-ICBLL",0x0368}, {"B2-ICBLH",0x0369}, {"B2-ICAX1",0x036a}, {"B2-ICAX2",0x036b},
    {"B2-ICAX3",0x036c}, {"B2-ICAX4",0x036d}, {"B2-ICAX5",0x036e}, {"B2-ICAX6",0x036f},
    {"B3-ICHID",0x0370}, {"B3-ICDNO",0x0371}, {"B3-ICCOM",0x0372}, {"B3-ICSTA",0x0373},
    {"B3-ICBAL",0x0374}, {"B3-ICBAH",0x0375}, {"B3-ICPTL",0x0376}, {"B3-ICPTH",0x0377},
    {"B3-ICBLL",0x0378}, {"B3-ICBLH",0x0379}, {"B3-ICAX1",0x037a}, {"B3-ICAX2",0x037b},
    {"B3-ICAX3",0x037c}, {"B3-ICAX4",0x037d}, {"B3-ICAX5",0x037e}, {"B3-ICAX6",0x037f},
    {"B4-ICHID",0x0380}, {"B4-ICDNO",0x0381}, {"B4-ICCOM",0x0382}, {"B4-ICSTA",0x0383},
    {"B4-ICBAL",0x0384}, {"B4-ICBAH",0x0385}, {"B4-ICPTL",0x0386}, {"B4-ICPTH",0x0387},
    {"B4-ICBLL",0x0388}, {"B4-ICBLH",0x0389}, {"B4-ICAX1",0x038a}, {"B4-ICAX2",0x038b},
    {"B4-ICAX3",0x038c}, {"B4-ICAX4",0x038d}, {"B4-ICAX5",0x038e}, {"B4-ICAX6",0x038f},
    {"B5-ICHID",0x0390}, {"B5-ICDNO",0x0391}, {"B5-ICCOM",0x0392}, {"B5-ICSTA",0x0393},
    {"B5-ICBAL",0x0394}, {"B5-ICBAH",0x0395}, {"B5-ICPTL",0x0396}, {"B5-ICPTH",0x0397},
    {"B5-ICBLL",0x0398}, {"B5-ICBLH",0x0399}, {"B5-ICAX1",0x039a}, {"B5-ICAX2",0x039b},
    {"B5-ICAX3",0x039c}, {"B5-ICAX4",0x039d}, {"B5-ICAX5",0x039e}, {"B5-ICAX6",0x039f},
    {"B6-ICHID",0x03a0}, {"B6-ICDNO",0x03a1}, {"B6-ICCOM",0x03a2}, {"B6-ICSTA",0x03a3},
    {"B6-ICBAL",0x03a4}, {"B6-ICBAH",0x03a5}, {"B6-ICPTL",0x03a6}, {"B6-ICPTH",0x03a7},
    {"B6-ICBLL",0x03a8}, {"B6-ICBLH",0x03a9}, {"B6-ICAX1",0x03aa}, {"B6-ICAX2",0x03ab},
    {"B6-ICAX3",0x03ac}, {"B6-ICAX4",0x03ad}, {"B6-ICAX5",0x03ae}, {"B6-ICAX6",0x03af},
    {"B7-ICHID",0x03b0}, {"B7-ICDNO",0x03b1}, {"B7-ICCOM",0x03b2}, {"B7-ICSTA",0x03b3},
    {"B7-ICBAL",0x03b4}, {"B7-ICBAH",0x03b5}, {"B7-ICPTL",0x03b6}, {"B7-ICPTH",0x03b7},
    {"B7-ICBLL",0x03b8}, {"B7-ICBLH",0x03b9}, {"B7-ICAX1",0x03ba}, {"B7-ICAX2",0x03bb},
    {"B7-ICAX3",0x03bc}, {"B7-ICAX4",0x03bd}, {"B7-ICAX5",0x03be}, {"B7-ICAX6",0x03bf},
    {"PRNBUF",  0x03c0},  /*PRNBUF 1-39 */
    {"SUPERF",  0x03e8}, {"CKEY",    0x03e9}, {"CASSBT",  0x03ea}, {"CARTCK",  0x03eb},
    {"DERRF",   0x03ec}, {"ACMVAR",  0x03ed}, /*ACMVAR 1-10*/
    {"BASICF",  0x03f8}, {"MINTLK",  0x03f9}, {"GINTLK",  0x03fa}, {"CHLINK",  0x03fb},
    {"CHLINK+1",0x03fc}, {"CASBUF",  0x03fd},
  
    {"M0PF"  ,0xd000}, {"HPOSP0",0xd000}, {"M1PF"  ,0xd001}, {"HPOSP1",0xd001}, 
    {"M2PF"  ,0xd002}, {"HPOSP2",0xd002}, {"M3PF"  ,0xd003}, {"HPOSP3",0xd003},
    {"P0PF"  ,0xd004}, {"HPOSM0",0xd004}, {"P1PF"  ,0xd005}, {"HPOSM1",0xd005},
    {"P2PF"  ,0xd006}, {"HPOSM2",0xd006}, {"P3PF"  ,0xd007}, {"HPOSM3",0xd007},
    {"M0PL"  ,0xd008}, {"SIZEP0",0xd008}, {"M1PL"  ,0xd009}, {"SIZEP1",0xd009}, 
    {"M2PL"  ,0xd00a}, {"SIZEP2",0xd00a}, {"M3PL"  ,0xd00b}, {"SIZEP3",0xd00b},
    {"P0PL"  ,0xd00c}, {"SIZEM", 0xd00c}, {"P1PL"  ,0xd00d}, {"GRAFP0",0xd00d}, 
    {"P2PL"  ,0xd00e}, {"GRAFP1",0xd00e}, {"P3PL"  ,0xd00f}, {"GRAFP2",0xd00f},
    {"TRIG0" ,0xd010}, {"GRAFP3",0xd010}, {"TRIG1" ,0xd011}, {"GRAFM", 0xd011}, 
    {"TRIG2" ,0xd012}, {"COLPM0",0xd012}, {"TRIG3" ,0xd013}, {"COLPM1",0xd013},
    {"PAL"   ,0xd014}, {"COLPM2",0xd014}, {"COLPM3",0xd015}, {"COLPF0",0xd016},
    {"COLPF1",0xd017},
    {"COLPF2",0xd018}, {"COLPF3",0xd019}, {"COLBK", 0xd01a}, {"PRIOR", 0xd01b},
    {"VDELAY",0xd01c}, {"GRACTL",0xd01d}, {"HITCLR",0xd01e}, {"CONSOL",0xd01f},
    
    {"POT0"  ,0xd200}, {"AUDF1", 0xd200}, {"POT1"  ,0xd201}, {"AUDC1", 0xd201}, 
    {"POT2"  ,0xd202}, {"AUDF2", 0xd202}, {"POT3"  ,0xd203}, {"AUDC2", 0xd203},
    {"POT4"  ,0xd204}, {"AUDF3", 0xd204}, {"POT5"  ,0xd205}, {"AUDC3", 0xd205}, 
    {"POT6"  ,0xd206}, {"AUDF4", 0xd206}, {"POT7"  ,0xd207}, {"AUDC4", 0xd207},
    {"ALLPOT",0xd208}, {"AUDCTL",0xd208}, {"KBCODE",0xd209}, {"STIMER",0xd209}, 
    {"RANDOM",0xd20a}, {"SKREST",0xd20a}, {"POTGO", 0xd20b},
    {"SERIN", 0xd20d}, {"SEROUT",0xd20d}, {"IRQST", 0xd20e}, {"IRQEN", 0xd20e}, 
    {"SKSTAT",0xd20f}, {"SKCTL", 0xd20f},
    
    {"PORTA", 0xd300}, {"PORTB", 0xd301}, {"PACTL", 0xd302}, {"PBCTL", 0xd303},
    
    {"DMACTL",0xd400}, {"CHACTL",0xd401}, {"DLISTL",0xd402}, {"DLISTH",0xd403},
    {"HSCROL",0xd404}, {"VSCROL",0xd405}, {"PMBASE",0xd407}, {"CHBASE",0xd409},
    {"WSYNC", 0xd40a}, {"VCOUNT",0xd40b}, {"PENH",  0xd40c}, {"PENL",  0xd40d},
    {"NMIEN", 0xd40e}, {"NMIST" ,0xd40f}, {"NMIRES",0xd40f},
    
    {"AFP",   0xd800}, {"FASC",  0xd8e6}, {"IFP",   0xd9aa}, {"FPI",   0xd9d2},
    {"ZPRO",  0xda44}, {"ZF1",   0xda46}, {"FSUB",  0xda60}, {"FADD",  0xda66},
    {"FMUL",  0xdadb}, {"FDIV",  0xdb28}, {"PLYEVL",0xdd40}, {"FLD0R", 0xdd89},
    {"FLD0R", 0xdd8d}, {"FLD1R", 0xdd98}, {"FLD1P", 0xdd9c}, {"FST0R", 0xdda7},
    {"FST0P", 0xddab}, {"FMOVE", 0xddb6}, {"EXP",   0xddc0}, {"EXP10", 0xddcc},
    {"LOG",   0xdecd}, {"LOG10", 0xded1},
    
    {"DSKINV",0xe453}, {"CIOV",  0xe456}, {"SIOV",  0xe459}, {"SETVBV",0xe45c},
    {"SYSVBV",0xe45f}, {"XITVBV",0xe462}, {"SIOINV",0xe465}, {"SENDEV",0xe468},
    {"INTINV",0xe46b}, {"CIOINV",0xe46e}, {"SELFSV",0xe471}, {"WARMSV",0xe474},
    {"COLDSV",0xe477}, {"RBLOKV",0xe47a}, {"CSOPIV",0xe47d}, {"PUPDIV",0xe480},
    {"SELFTSV",0xe483},{"PENTV", 0xe486}, {"PHUNLV",0xe489}, {"PHINIV",0xe48c},
    {"GPDVV", 0xe48f}
    };
  int symtable_size=sizeof(symtable)/sizeof(symtable_rec);
#endif

/* Opcode type:
   bits 1-0 = instruction length
   bit 3    = instruction writes to memory (without stack-manipulating instructions)
   bits 7-4 = adressing type:
     0 = NONE (implicit)
     1 = ABSOLUTE
     2 = ZPAGE
     3 = ABSOLUTE_X
     4 = ABSOLUTE_Y
     5 = INDIRECT_X
     6 = INDIRECT_Y
     7 = ZPAGE_X
     8 = ZPAGE_Y
     9 = RELATIVE
     A = IMMEDIATE
     B = STACK 2 (RTS)
     C = STACK 3 (RTI)
     D = INDIRECT (JMP () )
     E = ESC RTS
     F = ESC
*/     
#if defined(MONITOR_BREAK) || defined(MONITOR_HINTS)
static UBYTE optype6502[256] = {
  0x01, 0x52, 0x01, 0x5a, 0x22, 0x22, 0x2a, 0x2a, 0x01, 0xa2, 0x01, 0xa2, 0x13, 0x13, 0x1b, 0x1b,
  0x92, 0x62, 0x01, 0x6a, 0x72, 0x72, 0x7a, 0x7a, 0x01, 0x43, 0x01, 0x4b, 0x33, 0x33, 0x3b, 0x3b,
  0x13, 0x52, 0x01, 0x5a, 0x22, 0x22, 0x2a, 0x2a, 0x01, 0xa2, 0x01, 0xa2, 0x13, 0x13, 0x1b, 0x1b,
  0x92, 0x62, 0x01, 0x6a, 0x72, 0x72, 0x7a, 0x7a, 0x01, 0x43, 0x01, 0x4b, 0x33, 0x33, 0x3b, 0x3b,
  0xc1, 0x52, 0x01, 0x5a, 0x22, 0x22, 0x2a, 0x2a, 0x01, 0xa2, 0x01, 0xa2, 0x13, 0x13, 0x1b, 0x1b,
  0x92, 0x62, 0x01, 0x6a, 0x72, 0x72, 0x7a, 0x7a, 0x01, 0x43, 0x01, 0x4b, 0x33, 0x33, 0x3b, 0x3b,
  0xb1, 0x52, 0x01, 0x5a, 0x22, 0x22, 0x2a, 0x2a, 0x01, 0xa2, 0x01, 0xa2, 0xd3, 0x13, 0x1b, 0x1b,
  0x92, 0x62, 0x01, 0x6a, 0x72, 0x72, 0x7a, 0x7a, 0x01, 0x43, 0x01, 0x4b, 0x33, 0x33, 0x3b, 0x3b,
  0xa2, 0x5a, 0x01, 0x5a, 0x2a, 0x2a, 0x2a, 0x2a, 0x01, 0xa2, 0x01, 0xa2, 0x1b, 0x1b, 0x1b, 0x1b,
  0x92, 0x6a, 0x01, 0x6a, 0x7a, 0x7a, 0x8a, 0x8a, 0x01, 0x4b, 0x01, 0x4b, 0x33, 0x3b, 0x43, 0x43,
  0xa2, 0x52, 0xa2, 0x52, 0x22, 0x22, 0x22, 0x22, 0x01, 0xa2, 0x01, 0xa2, 0x13, 0x13, 0x13, 0x13,
  0x92, 0x62, 0x01, 0x62, 0x72, 0x72, 0x82, 0x82, 0x01, 0x43, 0x01, 0x43, 0x33, 0x33, 0x43, 0x43,
  0xa2, 0x52, 0xa2, 0x5a, 0x22, 0x22, 0x2a, 0x2a, 0x01, 0xa2, 0x01, 0xa2, 0x13, 0x13, 0x1b, 0x1b,
  0x92, 0x62, 0xe2, 0x6a, 0x72, 0x72, 0x7a, 0x7a, 0x01, 0x43, 0x01, 0x4b, 0x33, 0x33, 0x3b, 0x3b,
  0xa2, 0x52, 0xa2, 0x5a, 0x22, 0x22, 0x2a, 0x2a, 0x01, 0xa2, 0x01, 0xa2, 0x13, 0x13, 0x1b, 0x1b,
  0x92, 0x62, 0xf2, 0x6a, 0x72, 0x72, 0x7a, 0x7a, 0x01, 0x43, 0x01, 0x4b, 0x33, 0x33, 0x3b, 0x3b };
#endif	/* MONITOR_BREAK || MONITOR_HINTS */
  

char *get_token(char *string)
{
	static char *s;
	char *t;

	if (string)
		s = string;				/* New String */

	while (*s == ' ')
		s++;					/* Skip Leading Spaces */

	if (*s) {
		t = s;					/* Start of String */
		while (*s != ' ' && *s) {	/* Locate End of String */
			s++;
		}

		if (*s == ' ') {		/* Space Terminated ? */
			*s = '\0';			/* C String Terminator */
			s++;				/* Point to Next Char */
		}
	}
	else {
		t = NULL;
	}

	return t;					/* Pointer to String */
}

int get_dec(char *string, UWORD * decval)
{
	int idecval;
	char *t;

	t = get_token(string);
	if (t) {
		sscanf(t, "%d", &idecval);
		*decval = idecval;
		return 1;
	}
	return 0;
}

int get_hex(char *string, UWORD * hexval)
{
	int ihexval;
	char *t;

	t = get_token(string);
	if (t) {
		sscanf(t, "%X", &ihexval);
		*hexval = ihexval;
		return 1;
	}
	return 0;
}

static UBYTE get_dlist_byte(UWORD *addr)
{
	UBYTE result = dGetByte(*addr);
	(*addr)++;
	if ((*addr & 0x03ff) == 0)
		(*addr) -= 0x0400;
	return result;
}

UWORD break_addr;
UWORD ypos_break_addr=0xffff;
UBYTE break_step=0;
UBYTE break_cim=0;
UBYTE break_here=0;
UBYTE show_inst=0;
UBYTE break_ret=0;
int ret_nesting=0;
int brkhere=0;

void monitorEnter(void)
{
	UWORD addr;
        char prBuff[256];

	addr = 0;

	CPU_GetStatus();
	
#ifdef MONITOR_BREAK
        if (show_inst && !break_step)
        {  /*break was caused by "O" command */
          break_addr=0;
        }
        if (break_here) {
                ControlManagerMonitorPrint("(Break due to BRK opcode)\n");
                show_inst=1;
        }
	if (show_inst)  /*this part will disassemble actual instruction & show some hints */
	{
	  UWORD value = 0;
	  UBYTE optype;
	  
	  if (break_ret)
	      ControlManagerMonitorPrint("(return)\n");

	  show_inst=0;
	  show_instruction(regPC,20);
	  optype=optype6502[memory[regPC]]>>4;
	  switch (optype)
	  {
	    case 0x1:
	       value=memory[regPC+1]+(memory[regPC+2]<<8);
	       value=memory[value];
	       break;
	    case 0x2:
	       value=memory[memory[regPC+1]];
	       break;
	    case 0x3:
	       value=memory[(memory[regPC+2]<<8)+memory[regPC+1]+regX];
	       break;
	    case 0x4:
	       value=memory[(memory[regPC+2]<<8)+memory[regPC+1]+regY];
	       break;
	    case 0x5:
	       value=(UBYTE)(memory[regPC+1]+regX);
	       value=(memory[(UBYTE)(value+1)]<<8)+memory[value];
	       value=memory[value];
	       break;
	    case 0x6:
	       value=memory[regPC+1];
	       value=(memory[(UBYTE)(value+1)]<<8)+memory[value]+regY;
	       value=memory[value];
	       break;
	    case 0x7:
	       value=memory[(UBYTE)(memory[regPC+1]+regX)];
	       break;
	    case 0x8:
	       value=memory[(UBYTE)(memory[regPC+1]+regX)];
	       break;
	    case 0x9:
	       switch(memory[regPC])
	       {
	         case 0x10:  /*BPL*/
	           if (!(regP & N_FLAG)) value=1;
	           break;
	         case 0x30:  /*BMI*/
	           if (regP & N_FLAG) value=1;
	           break;
	         case 0x50:  /*BVC*/
	           if (!(regP & V_FLAG)) value=1;
	           break;
	         case 0x70:  /*BVS*/
	           if (regP & V_FLAG) value=1;
	           break;
	         case 0x90:  /*BCC*/
	           if (!(regP & C_FLAG)) value=1;
	           break;
	         case 0xb0:  /*BCS*/
	           if (regP & C_FLAG) value=1;
	           break;
	         case 0xd0:  /*BNE*/
	           if (!(regP & Z_FLAG)) value=1;
	           break;
	         case 0xf0:  /*BEQ*/
	           if (regP & Z_FLAG) value=1;
	           break;
	       }
	       if (value==1) ControlManagerMonitorPrint("(Y) "); else ControlManagerMonitorPrint("(N) ");
	       break;
	    case 0xb:
	       value=memory[0x100+(UBYTE)(regS+1)]+(memory[0x100+(UBYTE)(regS+2)]<<8)+1;
	       break;
	    case 0xc:
	       value=memory[0x100+(UBYTE)(regS+2)]+(memory[0x100+(UBYTE)(regS+3)]<<8);
	       break;
	    case 0xd:
	       value=memory[regPC+1]+(memory[regPC+2]<<8);
	       value=memory[value]+(memory[value+1]<<8);
	       break;
	    case 0xe:
	       sprintf(prBuff,"(ESC %02X) ",memory[regPC+1]);
           ControlManagerMonitorPrint(prBuff);
	       value=memory[0x100+(UBYTE)(regS+1)]+(memory[0x100+(UBYTE)(regS+2)]<<8)+1;
	       break;
	    case 0xf:
	       sprintf(prBuff,"(ESC %02X) ",memory[regPC+1]);
           ControlManagerMonitorPrint(prBuff);
	       break;
	       
	  } 
	  if (optype!=0x0 && optype!=0x9 && optype!=0xa && optype!=0xf && 
	      memory[regPC]!=0x4c && memory[regPC]!=0x20)
        {
	    sprintf(prBuff,"(%04X)  ",value);
        ControlManagerMonitorPrint(prBuff);
        }
	  sprintf(prBuff,"PC=%04x, A=%02x, S=%02x, X=%02x, Y=%02x, P=%02x\n> ",
				   regPC,
				   regA,
				   regS,
				   regX,
				   regY,
				   regP);
      ControlManagerMonitorPrint(prBuff);
	} else /*if show_inst was not set */
	    if (break_addr==regPC) {sprintf(prBuff,"(breakpoint at %X)\n> ",(int)break_addr);
                                ControlManagerMonitorPrint(prBuff); }
	    else if (break_cim) ControlManagerMonitorPrint("(CIM encountered)\n> ");
	break_cim=0;
        break_here=0;
	break_step=0;
	break_ret=0;
#endif	
}

int monitorCmd(char *input)
{
    static UWORD addr = 0;
    static char s[128];
    static char prBuff[4096];
    static char old_s[sizeof(s)]=""; /*GOLDA CHANGED*/
    static int p;

	{
		char *t;

		RemoveLF(input);
                strncpy(s,input,127);
                if (assemblerMode) {
                    assemblerAddr = assembler(s);
                    return(0);
                    }
		if (s[0])
			memcpy(old_s, s, sizeof(s));
		else {
			int i;

			/* if no command is given, restart the last one, but remove all
			 * arguments, so after a 'm 600' we will see 'm 700' ...
			 */
			memcpy(s, old_s, sizeof(s));
			for (i = 0; i < sizeof(s); ++i)
				if (isspace(s[i])) {
					s[i] = '\0';
					break;
				}
		}
		t = get_token(s);
		if (t == NULL) {
			return(0);
		}
		for (p = 0; t[p] != 0; p++)
			if (islower(t[p]))
				s[p] = toupper(t[p]);

		if (strcmp(t, "CONT") == 0) {
#ifdef PROFILE
			int i;

			for (i = 0; i < 256; i++)
				instruction_count[i] = 0;
#endif
			return -1;
		}
#ifdef MONITOR_BREAK
		else if (strcmp(t, "BRKHERE") == 0) {
			char *brkarg;
			brkarg = get_token(NULL);
			if (brkarg) {
                                if (strcmp(brkarg, "on") == 0) {
                                        brkhere = 1;
                                }
                                else if (strcmp(brkarg, "off") == 0) {
                                        brkhere = 0;
                                }
                                else {
                                        ControlManagerMonitorPrint("invalid argument: usage BRKHERE on|off\n");
                                }
                        }
                        else {
                                sprintf(prBuff,"BRKHERE is %s\n",brkhere ? "on" : "off");
                                ControlManagerMonitorPrint(prBuff);
                        }
		}
		else if (strcmp(t, "BREAK") == 0) {
			get_hex(NULL, &break_addr);
		}
		else if (strcmp(t, "YBREAK") == 0) {
			get_dec(NULL, &ypos_break_addr);
		}
		else if (strcmp(t, "HISTORY") == 0) {
			int i;
			for (i = 0; i < REMEMBER_PC_STEPS; i++) {
				UWORD addr1,addr;
				int j;
				addr=remember_PC[(remember_PC_curpos+i)%REMEMBER_PC_STEPS];
#ifdef NEW_CYCLE_EXACT
				sprintf(prBuff,"%3d  ", (remember_xpos[(remember_xpos_curpos+i)%REMEMBER_PC_STEPS]>>8));
                                ControlManagerMonitorPrint(prBuff);
				sprintf(prBuff,"%3d  ", (remember_xpos[(remember_xpos_curpos+i)%REMEMBER_PC_STEPS]&0xff));
                                ControlManagerMonitorPrint(prBuff);
#endif
				sprintf(prBuff,"%04X ", addr);
                                ControlManagerMonitorPrint(prBuff);
				addr1 = show_instruction(addr, 20);
				sprintf(prBuff,"; %Xcyc ; ", cycles[dGetByte(addr)]);
                                ControlManagerMonitorPrint(prBuff);
				for (j = 0; j < addr1; j++){
					sprintf(prBuff,"%02X ", dGetByte((UWORD) (addr + j)));
                                        ControlManagerMonitorPrint(prBuff);
				}
				ControlManagerMonitorPrint("\n");
			}
			ControlManagerMonitorPrint("\n");
		}
		else if (strcmp(t, "JUMPS") == 0) {
			int i;
			for (i = 0; i < REMEMBER_JMP_STEPS; i++)
                {
				sprintf(prBuff,"%04x  ", remember_JMP[(remember_jmp_curpos+i)%REMEMBER_JMP_STEPS]);
                ControlManagerMonitorPrint(prBuff);
                }
			ControlManagerMonitorPrint("\n");
		}
#endif
		else if (strcmp(t, "DLIST") == 0) {
			static UWORD tdlist;
			UWORD addr;
                        char *token;
                        int num;
			int done = FALSE;
			int nlines = 0;
                        token = get_token(NULL);
                        if (token != NULL) {
                            if (strcmp("curr", token) == 0) {
                               tdlist = dlist;
                               }
                            else {
                                sscanf(token, "%X", &num);
                                tdlist = num;
                                }
                            }
			while (!done) {
				UBYTE IR;

				sprintf(prBuff,"%04x: ", tdlist);
                                ControlManagerMonitorPrint(prBuff);

				IR = get_dlist_byte(&tdlist);

				if (IR & 0x80)
					ControlManagerMonitorPrint("DLI ");

				switch (IR & 0x0f) {
				case 0x00:
					sprintf(prBuff,"%d BLANK", ((IR >> 4) & 0x07) + 1);
                                        ControlManagerMonitorPrint(prBuff);
					break;
				case 0x01:
					addr = get_dlist_byte(&tdlist);
					addr |= get_dlist_byte(&tdlist) << 8;
					if (IR & 0x40) {
						sprintf(prBuff,"JVB %04x ", addr);
                                                ControlManagerMonitorPrint(prBuff);
						done = TRUE;
					}
					else {
						sprintf(prBuff,"JMP %04x ", addr);
                                                ControlManagerMonitorPrint(prBuff);
						tdlist = addr;
					}
					break;
				default:
					if (IR & 0x40) {
						addr = get_dlist_byte(&tdlist);
						addr |= get_dlist_byte(&tdlist) << 8;
						sprintf(prBuff,"LMS %04x ", addr);
                                                ControlManagerMonitorPrint(prBuff);
					}
					if (IR & 0x20)
						ControlManagerMonitorPrint("VSCROL ");

					if (IR & 0x10)
						ControlManagerMonitorPrint("HSCROL ");

					sprintf(prBuff,"MODE %X ", IR & 0x0f);
                                        ControlManagerMonitorPrint(prBuff);
				}

				ControlManagerMonitorPrint("\n");
				nlines++;

				if (nlines == 29)
                                    done = TRUE;
			}
		}
		else if (strcmp(t, "SETPC") == 0) {
			get_hex(NULL, &addr);

			regPC = addr;
		}
		else if (strcmp(t, "SETS") == 0) {
			get_hex(NULL, &addr);
			regS = addr & 0xff;
		}
		else if (strcmp(t, "SETA") == 0) {
			get_hex(NULL, &addr);
			regA = addr & 0xff;
		}
		else if (strcmp(t, "SETX") == 0) {
			get_hex(NULL, &addr);
			regX = addr & 0xff;
		}
		else if (strcmp(t, "SETY") == 0) {
			get_hex(NULL, &addr);
			regY = addr & 0xff;
		}
		else if (strcmp(t, "SETN") == 0) {
			get_hex(NULL, &addr);
			if (addr)
				SetN;
			else
				ClrN;
		}
		else if (strcmp(t, "SETV") == 0) {
			get_hex(NULL, &addr);
			if (addr)
				SetV;
			else
				ClrV;
		}
		else if (strcmp(t, "SETD") == 0) {
			get_hex(NULL, &addr);
			if (addr)
				SetD;
			else
				ClrD;
		}
		else if (strcmp(t, "SETI") == 0) {
			get_hex(NULL, &addr);
			if (addr)
				SetI;
			else
				ClrI;
		}
		else if (strcmp(t, "SETZ") == 0) {
			get_hex(NULL, &addr);
			if (addr)
				SetZ;
			else
				ClrZ;
		}
		else if (strcmp(t, "SETC") == 0) {
			get_hex(NULL, &addr);
			if (addr)
				SetC;
			else
				ClrC;
		}
#ifdef TRACE
		else if (strcmp(t, "TRON") == 0)
			tron = TRUE;
		else if (strcmp(t, "TROFF") == 0)
			tron = FALSE;
#endif
#ifdef PROFILE
		else if (strcmp(t, "PROFILE") == 0) {
			int i;

			for (i = 0; i < 10; i++) {
				int max, instr;
				int j;

				max = instruction_count[0];
				instr = 0;

				for (j = 1; j < 256; j++) {
					if (instruction_count[j] > max) {
						max = instruction_count[j];
						instr = j;
					}
				}

				if (max > 0) {
					instruction_count[instr] = 0;
					sprintf(prBuff,"%02x has been executed %d times\n",
						   instr, max);
                    ControlManagerMonitorPrint(prBuff);
				}
				else {
					ControlManagerMonitorPrint("Instruction Profile data not available\n");
					break;
				}
			}
		}
#endif
		else if (strcmp(t, "SHOW") == 0) {
			int i;
			sprintf(prBuff,"PC=%04x, A=%02x, S=%02x, X=%02x, Y=%02x, P=",
				regPC,regA,regS,regX,regY);
                        ControlManagerMonitorPrint(prBuff);
			for(i=0;i<8;i++) {
                                sprintf(prBuff,"%c",regP&(0x80>>i)?"NV*BDIZC"[i]:'-');
                                ControlManagerMonitorPrint(prBuff);
                                }
			ControlManagerMonitorPrint("\n");
		}
		else if (strcmp(t, "STACK") == 0) {
			UWORD ts,ta;
			for( ts = 0x101+regS; ts<0x200; ) {
				if( ts<0x1ff ) {
					ta = dGetByte(ts) | ( dGetByte(ts+1) << 8 );
					if( dGetByte(ta-2)==0x20 ) {
						sprintf(prBuff,"%04X : %02X %02X\t%04X : JSR %04X\n",
						ts, dGetByte(ts), dGetByte(ts+1), ta-2,
						dGetByte(ta-1) | ( dGetByte(ta) << 8 ) );
                                                ControlManagerMonitorPrint(prBuff);
						ts+=2;
						return(0);
					}
				}
				sprintf(prBuff,"%04X : %02X\n", ts, dGetByte(ts) );
                                ControlManagerMonitorPrint(prBuff);
				ts++;
			}
		}
#ifndef PAGED_ATTRIB
		else if (strcmp(t, "ROM") == 0) {
			UWORD addr1;
			UWORD addr2;

			int status;

			status = get_hex(NULL, &addr1);
			status |= get_hex(NULL, &addr2);

			if (status && addr1 <= addr2) {
				SetROM(addr1, addr2);
				sprintf(prBuff,"Changed Memory from %4x to %4x into ROM\n",
					   addr1, addr2);
                ControlManagerMonitorPrint(prBuff);
			}
			else {
				ControlManagerMonitorPrint("*** Memory Unchanged (Bad or missing Parameter) ***\n");
			}
		}
		else if (strcmp(t, "RAM") == 0) {
			UWORD addr1;
			UWORD addr2;

			int status;

			status = get_hex(NULL, &addr1);
			status |= get_hex(NULL, &addr2);

			if (status && addr1 <= addr2) {
				SetRAM(addr1, addr2);
				sprintf(prBuff,"Changed Memory from %4x to %4x into RAM\n",
					   addr1, addr2);
                ControlManagerMonitorPrint(prBuff);
			}
			else {
				ControlManagerMonitorPrint("*** Memory Unchanged (Bad or missing Parameter) ***\n");
			}
		}
		else if (strcmp(t, "HARDWARE") == 0) {
			UWORD addr1;
			UWORD addr2;

			int status;

			status = get_hex(NULL, &addr1);
			status |= get_hex(NULL, &addr2);

			if (status && addr1 <= addr2) {
				SetHARDWARE(addr1, addr2);
				sprintf(prBuff,"Changed Memory from %4x to %4x into HARDWARE\n",
					   addr1, addr2);
                                ControlManagerMonitorPrint(prBuff);
			}
			else {
				ControlManagerMonitorPrint("*** Memory Unchanged (Bad or missing Parameter) ***\n");
			}
		}
#endif
		else if (strcmp(t, "COLDSTART") == 0) {
			Coldstart();
			return -1;	/* perform reboot immediately */
		}
		else if (strcmp(t, "WARMSTART") == 0) {
			Warmstart();
			return -1;	/* perform reboot immediately */
		}
#ifndef PAGED_MEM
		else if (strcmp(t, "READ") == 0) {
			char *filename;
			UWORD addr;
			UWORD nbytes;
			int status;

			filename = get_token(NULL);
			if (filename) {
				status = get_hex(NULL, &addr);
				if (status) {
					status = get_hex(NULL, &nbytes);
					if (status) {
						FILE *f;

						if (!(f = fopen(filename, "rb")))
							perror(tus = get_s,ta;
(tus = get_s,ta;ar ef));
			return -1;	/* perf7
						FIL2/F7}, {"ROWINC",  0x02F8}, {"COLINC",
@= get_hex(NULL, &1, addJ1" ,  [p]olManaglse {
				ControlMaLL, &addr);
	addr
			UW *fil
@= get_hex(NULeH *fi
@= get_getFRkiil5d2fEM/ut_hex(NUL
	addr
			lRe {
	@} = FALSE;
			int nlines = 0;
   wnageS3T= get_s,ta;
(tus = get_s,ta;a00000fSCuff,"BRKHEaY=%02x   ,  0x00D4}, {"FR0+1" ,");
		}
		else[4orm reb  }
		il
@= ge\tr^		return -1;\tr^		retuB|s = //Bf	retuchar *filename;
			UWORD addr;
			UWORD nbytes;
			int status;

			filename = get_token(NULL);
			if (filenameeW *dr1);
			sname = gAisdr1);
			itorPrint(" {"B5-I2(agerMonitorP8I;i<8;i++)	BI2(agerMonitoL1,rPrint(prYjMSK",  0x0247},
X Y=%02x, P=%02 0x02470247},
da(NULA5d2fEM/ut_hex(NUL
	addr
			lRe {
	@} = ORJointf(pi]@} = E on|off\n")7f,      1,rP7f,      1,rP7t_hext	 E onLrPr     
			lReE op6}cmp(t, BRK opcode)\n");
     t, "COLDSTAif
		yU4jmp(b	lReE o, 0x6aMMMMMMMMMMMMMlF yU4jmp(b),Ds &anager#eE o, if
		AAgMMMMMMlReE AAgxff;
		, if
}M10ZL4",  0*;
		, if
}M10ZL4
		yU4jmp(b	lReE o, 0x6aMMMMMMMMMMMMMNI, 0x6aMMMMMMMMlx6aADDCTL",[1a3b, 3b, *6aADDCTL",[1a3b,
		, if
}M10ZL4",  0*;
		, if
}M10ZL4NI 0*;
		, if
}Ml;
	P\3f,"%04X ", adMMMMMMlF yU4jmp(b),Ds &anag2AB+1 if ,0x035b},
    {"B1-ICAX3",0x035c}, {"B1-ICAX4",0x035d}, {"B1-ICA f   x035d}, "%04X ", adMMMMMMlF yU4jmp(b),Ds &anag{"CDTMF        2          
}M10ZL4");
 , "rb")-FsMMlF yU4jmp(b)01~B},
    {""""egPC,20);02 0x02470247},
da(NULA5d2fEM/ut_hex(NUL
	addr*2f0x0387}) {
	r/ut_r 2  O",  0x0Re {
	o0r misgE *f;

			M *f;

			M *f;

			M *f;    62E2e"CH"  2 CHANG1 {
	o0rAlse {
6ch   62E2e"CMY=%02x, P=%02 0x02470247},
da(NUL,
da(NUL,
 0x13, 0x52, lb, addr2){
	r/uCOLOR3",b#2GED_M(prBuff);
	       break;,
da(NUL,
 0x121];
	       value=(memory[(UBYTE)(value+1)]<ep5x 36}i<get_toke"CH"      462E2e"CH"  2,
  0xa2, 0x52, 0xa2, 0x5a, 0x22, 0x22, 0x2a, 0x2a, 0x01, 0xa2, 0x01, x2a, 0x2aL2/F7}, :T57X3",0x035, 0xa2,"FR0+1 7se {
6ch   62E2e"CMY=%02x, P=%02 0x02470247},
",0x035, 0xa2,"FR0dry froj t4 0x01, x2a, 0%02 0x0F          , {"B6-ICAXtrolManager/ , {"B6-I0se if (2470247}+1 7se {
%d35, 0xa2,/F7}, :T57X3",0x035, 0xa2       I,/Ff(prBuff,"%dT57X3",035, 0xa2,"xa2       35, 0xa2,"xaorPrint(/F7}, :T57X3",0x035, 0"" ,  0x00DE}, {"F)7f,T57X3",036ch   62E2e"CMY=%02x, P=%02 0x02470247, if
1	}
		}
#endif)7f,T57X3",036itorPrij62E2e"CMY=%02x, P=%02 0x02470247, if
;d (BadvColManager/ , C_STEPS;c  ControlMS'!x ", addr)lPS;c  ControlMV$H addrNUL
	addr
			lRe {
	@} = FALSE;
			int, addr)l       status) {E onLrPr     
			lReE op6}cmp(t,o"f40b}, {"PENH",  0xd40c}, {"PENL",  0xd40d}9:c(" {"B5-I2(1Aer/ , C_STEPS;c  ControlMr (i = 0; M=%02 0x02470247, if
1	}bint(prL= OR {"PENL6a, 07, if
1	}bi	Eop6}cmp(t,B5-I2(1Aer/ , C_STEPS;6re = 1;
                     FR{
%d35, 0xa2,/F7}, :T57X3",0x035, 0xa2       I,/Ff(prBuod     I,r0D4}, {"FR0+1"  *t;
C
@= get_hex(NULeH *f
@= get3fb},
  optype65   cse if ;\tr^0 ) {3rBuod   t3fbda(N, adMAL, &a0torEnter(_b adMAL,  torEnter(_b adMAL,  lL, &a0torEn    Contr}9:c(od   t3fbda(N, adMAL, &a0E] toRif ;\tr^0 Mofs(" {"B5-I2er/ ,s,
  optype65   cse if ;\tr^0 ) {3r;\tr^0 Mofs(" {"B5-I2er/ ,s,
r/ ,s,
  opty Contr}9:c(" {"B5-I2tr^RxEx0284},
  Sdr;
			om"SETV") == 0) {
			get_hex(NULL,s03 adMAL,  lL, &a0 adMAL03a3},
  L03a3},
  L03a,{"FR[j];"COLDSV",0>,L
    {"DDEVIC", gPI}, {"TABMAP+1",0S}9:F8}, {  {"DDEVIC"EDSV",0>,L
  bng 3, if
}M10ZL0STE ;\tr^0 ) a",0>,L
 &a0 adMAer/ ,  {"DDEVIC"EDSV",0>"465}, {"SE, if
}M10ZL0STE ;\tr^0 ) a",0>,L
 &a0 adMAer/ ,  adMAerP7,  0x02F6},
    6},
    4adMAL, &a0torn -1;\tm0305}}M10ZL0STE ;\tr^0 ) a",0>"4tr^0  O",   {"COLYBREAK") 0:c(" {L,  lL, &a0 a02}, B3-ICex(NUNUL,
 Cx92,et_t B3-ICex(NUNUL,
 Cx92,et_t B	static c  lL, &a0 a02}, B3-ICex(NUNUL,
 Cx9et_t B(o  ,0xd004}, {"HPOSM0",0xd004}, ") l1b, 0x1b,
  0x92,        ,s,
iTICex,
iTICexx(NUNUL,
 Cx92,et_t B	sUnter(_oL, &a0torEnter(_b e04}, ") l1b, 0x1b,
  0x9olManaE_oL, &a0torEnter(_b e04}, ") l1b, 0x1b,
  0x9 (addr)
				SetC;
			else
				C 0x9P
			else
				C 0x9P
			else
				C 0);02 0x0		UWORD addr			else
				C
				Clse
	t	get_hex(NULL, &addr);
			if (addr)
					t	get_hex(N ,
iTICex,
iTIC      ddr);
			if (addr)
					t	get_hex(N ,
iTICex,
iTIC      ddr);
			iOT1"  ,0xd201}, {"AUDC1", 0xd201}     9 = 	t	get_hex(DDEVICorEntSter(_. 462E2e"CH"  2,
  0xa2, 0x52, 0xa2, 0x5aO11", 0x2(1A3dULL, &a, 0xa2, 0x5aO11"LL, &addr);
			iXhu01}, 4s+1), ta-2,
						dGePC+2iULL, &a, .0xe480},
    {"S			,
  0xa2, 0x52, 0xa2, 0x5aO11", 0x2(1A3dT201}  X0x5aO11, C_xa2, 0x52, 0xa2, 0x5aO11", 0x2 0; M=%02 0x02470247, if
1	}bint(O11", 0x2 0; M=%02 0x0 one,3TEPS;c  ControlMr (i = 0; M=%02 0x02470247, if
1	}0x2 0;)tHL= 0; *HM(prBuff);ch   62}0x2 prBufdGetByHPOSM0",)		sprintf(prBuff,"%04X :Ireak;,1ICPTHCTLN",        ox02AE},
  S, addr);
    L+1",070247, if
1	}0x2 r);
    62}0x2 prBufdGCSM0",)		sprintf(E},
  S, a3NV",0xe4L+1r S, a3018}, {"COLPF3",0xd019}, {"COLBK", 0xd01a}, {"PRIOR", 0xd01b},
    {"VDELAY",0xd01c}, {"GRACTL",0xd01d}, {"H]nt(O11", 0x2 p(d01c},, addr);
    L+O"rb")))
							perror(tus = get_s,ta,
    {"V L+1",070247, K1, 0xa2070247, K1, 0xa2070247, K1P+1",02dMAL,,02S4,3TEPS;c  ControlMr (i = 0; M=%02 0x
		}
		elREPS;EPS;c  ContAb)
							perror(t9}, {"COLBK", 0ntrolMr (i , {"COLBK", 0ntrolMr,02S4247, ifxd019}, {"COLBK", 0xd01a}, {"PRIOR"T_s,ta,
  01a}tD addr	02S4Va,
  01a}tPe=R*h/]\tr^Va,
  01a}tPe=i  01a,
  CMr (Sa-2,ContA
			lMolMr Entfc7i_count[  {
	247, K1CBAH"1ntfc7i_countS4Via}, {"PRIOR"             b 01a}tPe=lMr E,
  0=lMr E,
  0=lMr E,
  0=lMr E,
  0=, K1P+1"0
			lMolMxtrcmp(t& 0xff;
		}
	 E,
  0T,E,
a2Ff(prBuod     I,r0D4}, ._32Ff(prBuod    01a}tPe=lMr E,
  0=lMr E2Ff(prBuod    01a}tPf2			i2ex,
iTolI[HTp_}tPf2			i2ex,
iToor(t9}, {"ch   62E2e"CMYI[HTp_}t(prBuod
iTICexx(NUNUL,
 Cx92,et_t B	sUnter(_oL, & 0=pRIB
		UBYTE bt(prB3!              et_r E,
   et_rJ_  0=lMr E2Ff(prBuod    01a}tPf2			i2ex,
iTolX5            = //Bf	retuchar }, {" Cont2tr^RxExd}, {" Cont2tr^RxExd}, {" Cont2tr^RxExd}, {" Ce ta-2,
:{" Cont2tr^Rx/0x1b+0HTp_}tPf2			i2ex,
iToor(t9}, {"ch}, {"ch   62E2E2Ff(p,  0xd40O				instr = j;
SP1+1}, {"C	instp_}t(pr2S4247, ifICPTL", j;
S      = //Bnstr = ",0>,L
  bng 3, if
}M10ZL0STE ;\tr^0 ) a",0> C_STEP0r E2)ContAb)
		eEP0r E2)Cont      ControlManagerMonito;
			else2			i2ex,
i4A:YLL, &addr1);
			status |= g+1"  *t;
C
@= get_hex(NULeH *f
@= get3fb}0oet_d2  Or@= get"i*t;
C
@= gf
@= get3;
(tu4LiASCex,
iTIC   F05me Cont}3fb}0oet_dname) @= get"i2 Con		eEP++;
	//Bf	     bre)i		ClrV;et"i*t;EP++;
PEP++;
teEP+a
@= get_FIZC"[i]STEi*t;EP+1"[i]STE)me) @10=,Pf2			i2ex,
iTolI[HTp_)ATiBse) @1
    4a;
				sprPTL"RierMon("*** Memo
    4a;
		

static U    4a;
		

stati
iTIC  TE)me) @10=,P  4a;
	neC'

			R4a;
		

1{"ch},)2}, {"ch   62Ech  iTI

1{"ch},)2}terMon(h},)2}terMon(
    {"PRNBUF",  0x03:a, 0x01,0x01,0x01,0x01,0x01,0x01,0x010STE ;\ )(value+1)",)		1,0x01hASBUF",  0ediatex,
iTolX5            = //Bf	retuchar }, {" Cont2tr^RxExd}, {" Cont2tr^RxExd}, {" Cont2tr^RxExd}, {" Ce ta-2,
:{" Cont2tr^Rx/0x1b+0HTp_}tPf2			i2ex,
iToor(t9}, {"ch}, {"ch   62E2E2Ff(p,  0xd40O				instr = j;
SP1+1}, {"C	instp_}t(pr2S4247, ifICPTL", j;
S     0247, if
1u+eltorPrint(" {"B5-I2(a0Jl, "SETN"str     {"PR   {"PR   {"29"ch   62E2El, "Sl, "orPrint(/F7},agerMonitorPASBUF",  0p0	o0r misgE *f;

		 addr2);
o0rO2in1)",,k1u+elt(" {"B5-I2(a0Jl,    62Eex,
it("Jl,  m]7R}tPf2			i2x01,HA			default:[L= 0; 0x7a, 0i2x01,HSnase 	instr = j4 	instr =_T1dr2Id01a}, 47, if
1u+eltorPrint(" {"B5-I2(a0Jl, "SETNd	*L0; 0x7a, 0i "Pd00			s++;
memory[iR			pe25UMl{"2r2++;
mem2u0torPnn1)",,k1u+elt(" {"B1)",,k1u+((E},
  S, a3NV",0x {"VSCROL",0xd405}, {"PMBxd405}, {"PMBxd405}, )  CoN"str  i"PR   {"2{"PMBxtatus)
					_}t(pr2		1,0x01hA"VCOUNT",0xd40b}, {"PENH"xtat001hA"V0T7" 01a}, R40b}, {"PENm]7R}tPfPENm]7"  ,Elr"VCOUNT",0xd40PR   {"2{"PMBxtatus)
					_}t(pr2	co,HMolManagerMonitpiprBuff);
	 uemory[iRS    /", 0xd01a}, 3nstruct3o,HM/", 0co,HMolMan6Um2u0torPnn1)",,k1u+elt(" {At     eeak;
	 0x "2r2++;
mem2u",0xd40b}2u",0xd40b}2u",0xd40b}2u",0xd40                  d40b}2i    S4a;
				sprPTL"RierMon("*** Memo
    4a;
		

st5o
    4a;
		

st5o0; *, {"COLBK", 0ntrolMr,02S4247, ifxd019}, {"COL		

st*K", 047  d4Y E/			/* Pointer to ,Q0ntU)3		els47  d4Y E/		M5)els4ierMon("*		get_hHerMon/", 0xnter toyU4jmp(b),;
	 0x ",etifxd019}      a_   {"PR s,o8019}  dvColMS4   4a;
		

st5o
    4aoorPnn1)",,k1u+elt(" {At     eeak;
	4A:YLL, &addr1);
DColMS4   YLL43, 0}, R40n("*** Memo
    4a
iToor(t8,K {At     e",)		spiH{"B2-ICP,4Pmo
 nToor(t>;
		else if (strcmp(t, "TROFF"	returnt, "TROFF"	returnt, "TROFF"	retMd4Y E/HTp_}t}, R40n("n("*0D4}, ._32Ff( 0x "Exe {
	iPnn1)",,k1u]040n("n("*0D4}, ._32Ff2  (0n("n(, R40xe {",,k1u]040n("F0e5, R40n("n("*0D4}, ._32Ff( 0x "Exe {
	iPnn1)",,k1u]040n("n("*0D4}, ._32Ff2  (0n("n(, R40xe {",,k1u]040n("F0e5, R40n("n("*0D4}, ._32Ff( 0x "Exe {
	iPnn1)",,k1u]040n("n("*0D4}, ._32Ff2  (0n("n(, R40xe {",,k1u]040n("F0e5, R40n("n("*0D4}, ._32Ff( 0x "Exe {
	iPnn1e, ._02>xe {
	iPnn1e, ._0rm4,4Pmo
 nT0n(0mo
    4a	?w{",,k1u]e 0xc:
2E2e"CMY=%02x, P=%02 0x0247E%02x, 62E2e"CMYI[HTp_}t(prBuod
iTICexx(NUNULti2/", 0xCexx(NUNULti2/32Ff2  (0n("n(, R40xe {",,k1u]040ConiX2",03iTe) @=xe {
	Utus)
	) @=xe {
	Utus)
	) @=xe {
	Utus)
	) iX2"ddr)iPnn1)",,k1u]0401u]04t>;
		 @=xe {
	Utus)
	) iX2"ddr)iPnn1)",,k1rm=0;
UBYTs) );
    0x "Exe {
	iPnn1e, ._02",0x036e}, se) @1
 f2  (0n("n(, R40xe {",,k1u],  0x0i0x0247E%02x, 62E2e"CMYI[HTp_}t(prBuod
i"i*t;TX2"ddr)iPn2M4      uff);a32Ff2  (0n("n(, R40xex "ECOLBK", 0nkA :Ireak;,TX2"ddr)ex "ECOLBK", 0nm.r2);
o0rO2in1)",,k1kA :IK", 0
   bitsen execu, {"B6-IC.d
i"i*t {"COLPF3",Lak_ad$/yI06-IC.iMX2"ddr)Fbitsen execu, {"B6-7},
da(on("nMX2"ddr)Fbitsen exec97"ddr)Fbn exeARP Buff,"% exec97"ddr)Fbn exeARP Buff,2u0torPnnLISTL",0xd402}, {"DAi,
da( M=%02 0ar(void)
{
	UWORD Buod
iTICexx(NUNULti2/", 0xCexx(NUNULtiCexx(NUNULtiCexx(NUNULtiCex0;,TX2"ddrk_ad0c8NNULtic8NNULtic8NNULtic8NNUL 0x10:iCexx(NiCexxlI[HTpMaLL, exxlI[20x70:  /*BVS*/
	       iCexx(NiCexxlI[HTpw", j;
S     *)
	) @=4d0torPnnLISTL",0xd402},  , {"PENms_", j;
S     tic8NNUL 0x10:iCcTpw", j;
ULtic8NNUL 0x10:iCexx(Nin("Fj;
SPFf2  (0) );
    "0x10:rAS"("Fje,xff;
		}
		else if 0x10:iCcyM4      uff);a32Ff2emory[regP4rNULtic8NNUL 0x10:iCe0:i2_32Ff2emory[reg"Fj;
SP10xc:
2-ICAX4u2-ICAX4u2-INNUL 0x10:iCe0:i2_32Ff2y[reg"Femory[regf 0x10:Ar2		1,0x01if 0x10intf(prBuff,"(ESC %02X) "
			int nUL 0x10sl3R{YO+ 0x10sl3R{YO+ 0x10sl3R{YO+ 0x10sl3R{YO+ 0x10sl3R{YO+ 0x10sl_eP2, &annLISTL",0xd4kp]);

 , {-FsMMlF yU4jmp(b)01~B},
    {U1]040nEc l2	l0) );
 U1]03hxdecdamemorlc8NNULtic8NNUL 0x10:iCexx(NiCex)c=xdecdamtiCexx(NUNULtiCex0;,TX2"ddr"*0D1~B},
jmp(b)01~B},
    {U1]040nEc l2	(NiCe{"PRNBUF",  0x03:a, 0x0 @=4d0torPnnLISTL",0xd402},  , {"PENms_", j;
S     tic8NNUL 0x10:iCcTpw", j;
ULtic8NNUL 0x10:iic8N. j;
ULti,TX2"ddnagerMonitorPrifLISTL",0x"8NNHodamtSN. j;
Ux10sl31 yU4jmp(b)01~Hy3 = ABSOy3 = ABSSN. j;
Ux	jmp(b)0torE,
0n("n(, R4B70247, K_hex(NUFf2/F7},h"RierM[regPC+2]<<8);
	       value=memory[value]+(memory[value+h(memorj;
ULti,TtiCexx(NUo
    1egPRddr2) A  4a;
		 {"DAi,
dr2) A  4a"0nitorPrint(prL"   ,0xdointo y   Smemor   value=memory[valuedointRu]040n("t8e]3HRp(b)01~Hy3h+2]<pG10", 0xded1},
    
y   Smemor   vB5-I2mory[valueT! "
			e,0", 0xded=memory[valub)01~Hy3h+2]<pG1lG10",f2/F7}#ir]T! "
			e,0i2/", 0xCir]T! "p(b)01~Hy3h+2ce 0x1:
13{YO+ 0xHof(s)atic c  lL4memory[value]+(memorypG1lG10",f2/F7* perf  et7* perf),;
	 0x ",et

				for (j = 1; j 	",f2/F7* perf 0", 0xded1},
    
Nms_", j;
S     tic8NNUL 0x10:iCcTy[01;
	    1;
	    1;
	        AE2e"CH"  }	damtiCeeeeeeeeT 1;
	    1;
	        AE2e"CH"  }	damtiCeeePf[4orm reb  }
T"29"ch   6T>E2e"CH},
    
]1eory[valu       orPs_",2d3isI
		}

1  addre"CH" :x10intf(prBuff,"(ESC %
T"29! {"DDNms_", j;
S     tic8NNULLrexeARP Buff,2u0torPnnLISTL",0SP3",0,0SP3",0,0S3",0,0S3",0,0S)uFf2  (+value]+(memory[value+h(memorj;
ULtis0hex(NULL, &addr1)nRP Buf0intf(prBuff,"(ESC perexecC %
T"29! {"Dor(t>;
	BD", o+ABf,"(E    b, 62E2e"CMYI[02}, B3-ICex(NUNmic8N; tic8E2e"CMYORJoinot(prLRsc8NNUL 0x10:iCcTpw"iolG10"f
		?e;
ULe2 6T>E2e"{    if (token !=f,"(E    b, 62E2e"CMYI 1; j < 256; j++) "{    ifk1u], rPlueTNmic8N; tic8E59}f,"%dT57X3) @=xe {
	_r=remember_PC[(remember_PC;
ULti1}, {"G y   Sme_0;

		Sme_e[2a, 0i5=xe C %
T"L C %
T"L C %
T"L  y   Sme_0;

		e2 6T>EE{    iE""Dor(t>xx(NUNULti2/" 0x1intfc
59}f,"%dT57X3) @=xe {v(memorj;
ULtis0hex%orPrij62E5 i00		 2y   SmLtic8NNUL 0x~Hy3{"G y   ~Hy3{"036"ys1a~Hy3{"036nLISTL",2y   SmLtichex%orPrij62E5 i00		 2y   SmLtice_eidr)F'0x10:iCexx1:
13{YO+table)/sizeof(syiNUL Ce"4tr^VIC", gPI}, {"PC[(remembisxd4kp]e"4tr^VIC", gPI}, {"PC[(remembisxd4kp]eIC", gPI}, KxyI06-IC.iMX2"ddr)Fbitsen execu, {"B, gPI}O+ 0x10sl3R{IC", )Fbitses (valm, 07, ifRm;
ULtisf,"(E   " {"B5tisfC", gP0x6aMMMMMMMMMo BRK opcodTtic0N_FLAG)=_FLAG0b}, {"PENHUL 0x10:iCcTpf ((*aU " {"B5		*s = 'ULL, &a, {"PEN= 'ULLPENHUL 0xD2
ULtisse if (2  NHUL 0xD2
ULtisse if ese if, o BRK opcodTtic0N_FLAG)=_FLAG0b}, {"PENH51tPe=R*h/]\C", gPI}, KxyI06-IC.iMX2"ddr)Fbitsen e9010b}, {"PENH51tPe=R*h/sxd4kp]e"4tr^VIC", gPI}, {"PC[(remembisxd4kp]eIC", gPI}, KxyI06-IC.iMX2"ddr)Fbitsen execu, {"B, gPI}O+ 0x10sl3R{I]eIC", gPK6aM 
ory[reg"cu, tses}'ULLP2/F7},h"A, tses}'ULLP2/F7},h"A, tses}'ULLP2/F7},h"A, tses}'ULLaMMMMMb}, {"PE035,A, tses}6R2/F7},h"A, tses}'ULLP2/F7}Rddr2) A  Lti1}, {"G y   Sme_0;

		Sme_e[2a |= g+1"  *t;
C
@= Cexx(Np]eI	else if (H]eIC",;3(5IC",;3(5IC",;3(5IC,N ,
iT (H]eIC",;3(5IC",;1td;mtiCeee gPK6aM 
ory[brf(wE2, 0x2aE2, 0x2aE2, 0x2aE2, 0x2aE2, 03cu, {"B, gPI}O+ 0x10sl3R{I]eIC"			/* Poin-8Sl$}, {"	}, {"	}, {"	}, {"	tse4NltL, g10sl3R{I]eIory[brf(wE2, tK710KpG10", 05l3R{I]eIory[b2e"CH/sizeof( |= gDory[b2e"CH/sizeotMd4Y		*s TIory[brf(wE2, mAG)=(memorypG02x, 6G)=(memARP      valu i			f(710KpprL"  ,etifxd019}      a_   {"PR s,o8019}  dvColMS4   4a;
		

st5o
    4aoorPnn1)",,k1u+elt(" {At     eeak;
	4A:YLL, &addr1);
DColMS4   YLL43, 0}, R40n("*** Memo
    4a
iToor(t8,K {At     e",)		spiH{"B2-ICP,4Pmo
 n4Pmo
 n4Pm[b2e"CH/sizeotMd4YDDEVIC", - g+emory[value+h(me,B!hEf(wE2,j{"036"ys1);
DColMS4g+emory5olMS4g+e   F+emoryb2e"C"036"ys1);
DCoEf(wE2,oeIory[b Ce ta-2,
:{" Cont2tr^Rx/0x1b+0HTp_}tPfb,
  ,j{"03    
Ne]+(mcerMonito;
			sto;
			sto;
			sto;
		8, 62E2e"CMYI 1; j < 256; j++) "{    ifk1r,k1u+elt(" {I;
			st,
  0xa2, e_0;

		Sme_e[2a |0xa2, a
  0=liE
			e,0", 0xdU-liE6",0,1iE6",0,y[value+h(me,B!h,0,1iE6",0,y[value+h(me,B!h, opcodTtic0N_FLAG)=_FL;dnamierM[S!h, opcodT5mfe,B!h, opcod}3e[2a |0xa2,rf(wE2, me,B!h, opcod}3e[2a |0xa2,rfe+h(,
:{wFsn8N; tic8eliE6",0,1(/F7}, :++;

				if (nlines == 29)
   ember_P6",0,ZL405l3R{I] LOiI 1; j < me,B!h, opcod}3e[2a |0xa2,rfe+h(,
,,k1u+elt(" {At  0,,k1u+elt(" {At  0,,k1 0,,k1u+e/R5opcodTtic0N_FLAG)=a |0xa2,-{I] LNG1 {
	o0rAlse {
6ch   62E2e"CMY=%02x,A9pr2	ierM[S!h, o  2,=a |0xa30rint/kCPEN=fb,
  ,j{"03    
Ne]+(mcerMonito;
 {
				sprintf(prBuff,"%04x  ", remembeUxmn1" 35, 0P0"03    
Nef,"R<8);
	      y001hA"V01t      y001hA"V01t      y001hA"V01t     {"B5		*s = 'ULL, &a, {"PEN= 'ULLPENHUL 0xD2,"%04x  ", remembeUxmn1" 35, 0P0"03    
Ne0"03    
*s = 'U<8);
	 |0xa30rint/kCPEN=fb   
*s = 'U<8);
	 |0xa30rint/kCPE1t    %04x, se) @1= 'U<8);
	 |0xa30rint/kCPEkCPEN0IR & 0;0,y[value+h(me,B!hi0torPnnLIS2(|0xa3
	 |0x
		?e0xa30r "SETA") = {
6ch   62E2/  %04=a |0xa30rint/kCPEN=fb,
  ,j{"03    
Ne]+(mcerMonm,j{"03    
Ne]+(mcerMonm,j{"03    
Ne]+(mcerMonICexx(NUNULti2/", 0xCexx(NUNULtiCexx(NU"V01t;
    L+, &adu3cu, ontrolManagerMonitorPrint(prBuff);
  orPrint(prL+, &adu3cu, on! prL+, &uff);
  orPrint(prL+,2.rint(plManagerMonitorPrint(prBuff)lue]+(memory[value+h(memorj;
ULti,TtiCexY?j{"03    
Ne]+(mcerMemory[iRS,
    {1sIer_PC;%04x, s_PC;rPrint(prBuf}"irolManagerMonito;
			else2			i2b   Buff)luFb,
 	 0x "2r2++;
mem2u",0xd403y[value+T2_rPnnLIS2(|0xa3
	s]1lfIS2(|0x>,
  oI1MMonito;
			else2	,/*BMI*/
	  Monito;rU<8);
	 |0xa30S,
    {nagerM C0x "Ex0n1x2O+ 0x1 02x,A9pr2 0x1 02x, _2 0x1 L+,2Y {"PRIRRD addr1,addr;
				int j			rM C0x "Ex0n1x2O+ 0x1.(,
,,k1&ufRxY?j{"03    
Ne]))U<8);
,rfe+h(,
:{wM C0x KYuRIRRC0x "Ex0tic8E2e"CMYORJoinot(prL.90x KYtrolMaT)Tc8E2e"CMYORult:[L= 0; 0x7a, 0i2x01,HSfN)0K opcodTtic0N_FLAG)=_FLAG0b}, {"PENH51tPe{ 2tT:[L= 0; 0x7a, 0i2x01,HSfN)0K opcodTtic0N_FLAG)=_FLAG0b}, {"PENH51tPe{ 2tT:[L	(NUNmic8N; tic8E2e"CMYORJoinot(pWc0N_FLAG)=_FLAG0b}, {"PENH51tPe{ PDtPe{ ts, dGetByte(ts) );
                 SMonitorPri%02x;"%04X ", adMMMMMMlF yU4jmp(b),Ds &01,HSfN)0K o r&01,, 0x2aE2, )0K o r&01,=I, )0K o, {.agX = 0x01, 0xa2, 0x13, 0x13, 0x13,0N_FLAG>oeIory[b Ce ta-2,
:{" Cont2tr^Rx/0x1b+0HTp_}tPf.		f(]}	e,&ntrolManag   
Ne]))4 Ce ta-2,
:{" Cont2tr^ont2tr^Rx/t2tr^ont2)4 Ce to;
		o,A9pr2 0x1 02x, _2 0x1 L+,2Y {"ORx/0x1b+0HTp_}tPf.		f(]}	e,&ntrolManag   
Ne]))4 Ce ta-2,
:, _2 0x1 L+,2Y {tnag    0);02 0x0		UWag    0);02 0x0		UWag    00);02 0x0		}f,"      sscanf(tdr);
                      olManag   
Ne]))4 Ce ta-Alse     00);02 0ag   f);
  orPrint(prL+, &adu3cu, on! prL+, &Pag   , 0x2 p(d orP	CJitorPrint(c2  , 0xag  
:, _2 0x16!l    exx(NgX = 0x01ry5ol	 0ag   f)d
DColMS4   YLf201ry5ol	 0a+, &adu34{x10:iCexx(NiCexxlI[HTpsi1", 0x2ControlManagerMonito34{x10:i1",02dMA3cub2e"C"036itorPrintoiCext(prL+, &adu33r1);
DCo a3NVh(me,0:iCVber_P6",0, o r&01,, 0x2aE2, )0K o r&01,=I, )0K o, {.d_byte(&Prin	e,&nadu3cu4LDNULtic8	T10ZL0STE ;\tr^0NULtic8S0.ManagerMoNK o r&0h2 0x1oor(t9}, {"cO     aPoNK o bo0NULtis}'UL20					break;
				9"ch   6T>E2e"CH},
    
]1eory[valu       orPs_",2d3isI
		}

1  addre"C			break;
				NK o   aPoNK o bo0NULtis}'UL20					breWn2Id01*1iE6",0,y[value+h(me,B!h, opcodlManagerMonitorPrint("DLI ");

				swf);
  oisaPoNK o bo0NULtis}'UL20					breWn2Id0M7P5olt2e0x2 p(d orP	CJitorPrint(c2  ,BM1",2d3isI
		}

1  addre"C	i0			 ta-22222223h[82S\i aPoNK o1*1i)ddre"C	i0			 2
Ps			int j	/R5opcodTtic0N_FLAG)=ar/R5opcodTtic0N_FLAG)=ar/R5addr	/R5opcod L+,2i=a |0xa30rint/kCPEN=fb,
  ,j{"03    
Ne]+(mcerMonito;
 {
				sprintf(;
			}
duMHdre"C	i0+,2i=a |0xa30rint/kCPEN=fEN=fwM Cf1	i0+,2_PC;
ULt;
	e1	i0+,2_C;
ULt,	addr |= get_dlisttorPranagerMAS_C;
ULt,	nb  
Ne]+(mcerMonito;
 {
				sprintf(;
			}:erMonito;
 {
tf(;
		;
 {
tf(eH ,j{"03 Itrcmp5				d _>xx(2         S4X ", = 'U<8);
	 |0xa30Hy3h+2ce 0x1:
13{YO+  |0xa   xx(2         S4Aa_   {"PR s,o8019} wsP4Aa_  L    tic8888;
C
@= get_hex(NULeH *listtorPranagerMAS_C;
Srl+rPranagerMO+ 0x10sl(B(_b  ,j{"03 Itrcmp5yj{"03  (mcer    AS_C;
y[iR			pe25UMl{")1*1iv8a[iR		             4Aa_  L    t		 2
Ps			int j	/R5opcodTtic0N_FLAG)=ar/R5opcesttorPranageE0pcodTtic0N_FLAa   A   br4Aa_   6to;
 {
				spriaB(X)=ar/R5o   tic8888;
C
@= get_hex(NULeH *listtorPranaR(prNULeH dA{")1*1iv8a[iR		         ,0", 0xded(1		         ,0.r1,addr;
				int j			rM;
	break_st	prNULeH d(prB    ;cTnt("DLI ")        ,0", 0L+,2ic888PJ$orPrint(p0L+,2i58a[];
	     	pe   ,0", 0r/R5o   tic8888;
C
@= I ")        ,0", 0L+,2ic88c8888;
N_FL0L+,0LI )ucfed (BarolManagerMonitorPrint(prBuff);
				}

				ControlMao801"
	)      7				}
, {" C4nt/kCPENSet7* pf!0:iCEag    00);02 0x0		}M}

				ControlMao801"
	) l1  ti	ControlMao801"
	) l1  t) l1  t) l1  onLrPr    aL+,2i58          ti	CoLeH *listtrolMao8 7		R"     CfMao8 7		RlMao8 7		R"     CfMao8 7		RlMao8 7		Rrl+rP'iR				return(0);
		}
		for (p = 0;l1  ti	Con 0;l1  t CfMao8 7		RlMao8 7		Rrl+rP'iR				return(0eH dA{8C"036itorPrintoiCext(prL+, &adu33r1);
DCo a3NVh(meif (nl Sdr;7		R			}
, {" C4nt/kCPfAS_C;
ntf(;
			}
d         if (assemblerMode) {
                          E(rememba;
		

s;
				sprintf(prB)rg0);02 0e  t) l1  t) l1  onLrPr    aL+,2i58          ti	CoL"irIot     0d );
tL+, &ad2a", 0L+,2ic888PJ$orPrint(p0L+,2i58a[];
	     	pe   ,0", 0r/R5o   tiB5	pe )tef,torPrintoiCext(prL+, &adu33r1);
DCo a3NVh(meif (nl Sdr;7		R			}
, {" C4nt/kCPfAS_C;
ntf(;
			}
d         if (assemblerMode) {
                          E(rememba;
		

s;
				sprintf(prB)rg0);02 0e  t) l1  t) l1  onLrPr    aL+,2i58          ti	CoL"irIot     0i	CoL"irIot     0i	CoL"irIot     0i	Co Sdr;7	dr;7	,tor8 7		R"     CfMao8turn(0)a;
y[g    00 29! {"Dor+;
y[Pr    aL+,2i58          ti	CoL"irIot     0 0i	Co8 7		R"     CfI       value=memorhBuff,"%		R"   "r  Buff,"%		R"   "r  BufCm    ti	CoL"irIot     0 0i	Co8 x0		}M}M(prBuff);	else M(prBuff)isff,"%	F 0x10:iCex ")   - + j)));
   	}
t_hex(NUe/T2tr*f;

	urn(0)a;
yemblerModel0|0xa30Hyembleeturn -1;	/* per2tr*fase 0xrn -1;	/T		}M}M(prBuff)per2tr*fase 0xrn -1;	/T		}M}M(prBuff)per25t     0i	CoL"irIot   L"irIot     0 S
yemblerModel0|0xa30Hyembl2]<<8);
	    A opcodlMarn -1;	/* per       <8);
	  A{8C"036itf(p r       <8if (syembleeturn -1;	/* per2tr*fase 	ifKx1b+0LNHUL 0xD2,"%32F ti	Co r    2t0,0SP3",0,scanf(t0c2F ti	C) ti	Co r   |x-1;	/* per       <8);
	  A{8C"036itf(p r       <   <8);
	UMBxd405}, {"PMBxd405}, )  CoN"str  i -1;	/* per    <8);
	  A{8C"036itf(p r    ,0,scanfb+0LNHULp r   )V0L+,2i58a[];
	     	pe   ,0", 0r/R5o   tic8888;
Cd 0r/R5o   tic88;
Cd 0r/GcCA
{
	UW Cont2t90r/GcC247024nt2t90r/Gc1o_C;
Srl+rPranagerMO+ 0x10sl(B(_b  ,j{"03 Itrcmp5yj{"03  (mcer    AS_C;
y[iR			pe25UMl{")1*1iv8a[iR		             4Aa_  L    t		 2
Ps			int j	/R5opcodTtic0N_FLAG)=ar/R5opcesttorPranageE0pcodTtic0N_FLAa   A   br4Aa_   6to;
 {
				spriaB(X)=ar/R5oE0pcodot     )=ar/R5oEDAi,
dr2) A  4a"0nNo_C;
Sr1r^RxExd}, {" Ce ta-2,
:{" 24Wxd}, {" Ce ta-2,ucfed j	cfed"405}42,uUMl{")S,
:{%oL"irIot     0i	Coy, {"2 {")S,
:{R_02>xe rCm    t0o r    0i	C_nl ,;3ill see 97		RlMacwm    t0+elt(" {At     eeak;
	 0x "2r2++;
mem2u",0xd40b}2u",0xd40b}2u",0xd40b}2u",0xd40                  d40b}2i    S4a;
				sprPTL"RierMon("*** Memo
    4a;
		

st5o
    4a;
		

st5o0; *nagerMAS_C;
ULt,	nb  
Ne]+(mcerMonito;
 {
				spr2) A  4I "d&/    <LL, *nagerMAS_axff;
MASd  0=83-ICe7S_axff;
MASd	spr2) A   Ce ta-2,
:{" 24Wxd}, {" h,"]	BXOb}2u", t0o r  cXOb}2u", t0o r  a",0>,L
 &a0 adMAer/ ,  {"DDEVIC"EDSV",nt/kCPfAS_WORD nbyt   6to;
 {
				spriaB(X)=a_nt/kC		

ff;
MASd	spr2) A   Ce 